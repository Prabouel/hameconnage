define config.name = _("Mission Hameçonnage")
define build.name = "mission_hameconnage"
define config.version = "1.9"
define gui.show_name = True
define config.has_sound = True
define config.has_music = True
define config.has_voice = False
define config.main_menu_music = None
define config.enter_transition = dissolve
define config.exit_transition = dissolve
define config.after_load_transition = None
define config.end_game_transition = fade

init python:
    build.classify("**~", None)
    build.classify("**.bak", None)
    build.documentation("*.html")
    build.documentation("*.txt")
