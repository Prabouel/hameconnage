# MISSION HAMECONNAGE — ressource pédagogique Ren'Py
# Contenus originaux : CC BY-NC-SA 4.0 (hors Ren'Py et future identité visuelle institutionnelle)

define narrator = Character(None)

default score = 0
default erreurs = 0
default niveau = 1
default use_sfx = True
default use_music = True
default scenario_result = ""
default evidence_result = ""

init python:
    import random

    def shuffled(items):
        result = list(items)
        random.shuffle(result)
        return result

    def optional_audio_exists(path):
        return renpy.loadable(path)

    def start_music():
        if use_music and optional_audio_exists("audio/mission_theme.ogg"):
            renpy.music.play("audio/mission_theme.ogg", channel="music", loop=True, fadein=1.0)

    def stop_music():
        renpy.music.stop(channel="music", fadeout=.5)

    def play_sfx(path):
        if use_sfx and optional_audio_exists(path):
            renpy.sound.play(path)

    def toggle_music():
        global use_music
        use_music = not use_music
        if use_music:
            start_music()
        else:
            stop_music()
        renpy.restart_interaction()

    def register_answer(correct):
        global score, erreurs
        if correct:
            score += 1
            play_sfx("audio/good.ogg")
        else:
            erreurs += 1
            play_sfx("audio/bad.ogg")

image bg mission = im.Scale("images/bg_hameconnage.png", 1280, 720)

screen hud():
    zorder 20
    frame:
        xalign .01
        ypos 10
        background Solid("#071827DD")
        padding (13, 8)
        hbox:
            spacing 22
            text "SCORE [score]/16" size 18 color "#7FE7FF"
            text "ERREURS [erreurs]" size 18 color "#FFD58A"
            text "SITUATION [niveau]/8" size 18 color "#FFFFFF"

screen audio_controls():
    zorder 20
    hbox:
        xalign .985
        ypos 12
        spacing 8
        textbutton ("Musique : ON" if use_music else "Musique : OFF"):
            action Function(toggle_music)
            text_size 16
            xminimum 135
        textbutton ("Effets : ON" if use_sfx else "Effets : OFF"):
            action ToggleVariable("use_sfx")
            text_size 16
            xminimum 125

screen card(txt, button_text="CONTINUER"):
    modal True
    frame:
        align (.5, .57)
        xsize 1040
        ymaximum 520
        background Solid("#071522EE")
        padding (26, 20)
        vbox:
            xfill True
            spacing 16
            text txt:
                size 27
                color "#FFFFFF"
                text_align .5
                xalign .5
                xsize 950
            textbutton button_text:
                xalign .5
                xminimum 270
                action Return()
                text_size 22

screen question_card(title, prompt, choices):
    modal True
    frame:
        xalign .5
        ypos 78
        xsize 1120
        ysize 620
        background Solid("#071522EE")
        padding (26, 18)
        vbox:
            xfill True
            spacing 9
            text title:
                size 19
                color "#7FE7FF"
                xalign .5
                text_align .5
                xsize 1030
            text prompt:
                size 21
                color "#FFFFFF"
                text_align .5
                xalign .5
                xsize 1020
            null height 2
            for label, value in choices:
                textbutton label:
                    xalign .5
                    xsize 980
                    yminimum 52
                    action Return(value)
                    background Solid("#123A56DD")
                    hover_background Solid("#1E6B8CDD")
                    insensitive_background Solid("#123A56DD")
                    padding (18, 10)
                    text_size 18
                    text_xsize 920
                    text_text_align .5
                    text_xalign .5

screen final_screen():
    modal True
    frame:
        align (.5, .55)
        xsize 1020
        ymaximum 570
        background Solid("#071522F2")
        padding (35, 28)
        vbox:
            spacing 18
            text "MISSION TERMINÉE" size 37 color "#7FE7FF" xalign .5
            text "Score : [score] / 16 — Erreurs : [erreurs]" size 26 color "#FFFFFF" xalign .5
            if score >= 14:
                text "Expert de la vérification :\ntu analyses avant d'agir\net tu sais éviter les faux positifs." size 23 text_align .5 xalign .5
            elif score >= 10:
                text "Enquêteur vigilant : les bons réflexes sont là.\nPense à vérifier par un autre canal." size 23 text_align .5 xalign .5
            else:
                text "Apprenti enquêteur : ralentis et observe les indices.\nNe décide jamais à partir d'un seul détail." size 23 text_align .5 xalign .5
            text "LA MÉTHODE V.E.R.I.F.\nVérifier l'expéditeur — Examiner l'adresse — Résister à l'urgence\nInspecter sans cliquer — Faire confirmer" size 21 color "#FFD58A" text_align .5 xalign .5
            hbox:
                xalign .5
                spacing 25
                textbutton "REJOUER":
                    action Jump("start")
                    xminimum 250
                textbutton ("ACCUEIL" if renpy.variant("web") else "QUITTER"):
                    action (Return() if renpy.variant("web") else Quit(confirm=False))
                    xminimum 250

label start:
    $ score = 0
    $ erreurs = 0
    $ niveau = 1
    scene bg mission
    show screen hud
    show screen audio_controls

    call screen card("MISSION HAMEÇONNAGE\n\nTu rejoins une cellule de vérification numérique.\nHuit messages ont été signalés : certains sont frauduleux,\nd'autres sont légitimes.\n\nTon défi : décider sans te précipiter\net expliquer comment vérifier.", "COMMENCER")
    $ start_music()
    call screen card("Un message inhabituel n'est pas forcément une arnaque.\nUn message très soigné peut être frauduleux.\n\nTu gagneras 1 point pour le bon diagnostic\net 1 point pour la meilleure vérification, soit 16 points.")
    jump s1

label s1:
    $ niveau = 1
    $ scenario_result = renpy.call_screen("question_card", "SITUATION 1 — Le compte bloqué", "De : Assistance ENT\n<securite@ent-college-aide.com>\n\n'Votre compte sera supprimé dans 30 minutes.\nConfirmez immédiatement votre mot de passe\navec le lien ci-dessous.'", shuffled([
        ("C'est probablement un hameçonnage.", "good"),
        ("C'est légitime : le message connaît le nom de l'ENT.", "bad"),
        ("Impossible à savoir : je clique pour voir.", "bad"),
        ("Je réponds en envoyant seulement mon identifiant.", "bad")]))
    $ register_answer(scenario_result == "good")
    if scenario_result == "good":
        call screen card("Bonne analyse.\n\nL'urgence, la menace et la demande de mot de passe\nsont trois signaux d'alerte.")
    else:
        call screen card("Attention : connaître le nom d'un service ne prouve rien.\n\nUn organisme sérieux ne demande pas\nton mot de passe par courriel.")
    $ evidence_result = renpy.call_screen("question_card", "LA PREUVE DÉCISIVE", "Quelle vérification est la plus sûre ?", shuffled([
        ("Ouvrir l'ENT depuis mon favori ou son adresse habituelle,\nsans utiliser le lien.", "good"),
        ("Répondre au message pour demander s'il est authentique.", "bad"),
        ("Cliquer puis regarder si le site paraît professionnel.", "bad"),
        ("Transférer le courriel à un camarade pour qu'il teste le lien.", "bad")]))
    $ register_answer(evidence_result == "good")
    call screen card("Réflexe : ne passe pas par le chemin\nproposé par le message.\n\nRejoins le service par ton accès habituel.")
    jump s2

label s2:
    $ niveau = 2
    $ scenario_result = renpy.call_screen("question_card", "SITUATION 2 — Le SMS de livraison", "SMS : 'Votre colis ne tient pas dans la boîte.\nChoisissez un nouveau créneau et réglez 0,99 € :\nlivraison-suivi24.info'\n\nTu n'attends aucun colis.", shuffled([
        ("C'est très probablement un smishing, un hameçonnage par SMS.", "good"),
        ("Le faible montant montre que le SMS est sans danger.", "bad"),
        ("Je paie : au pire je ne perds que 0,99 €.", "bad"),
        ("Je réponds STOP avant de supprimer le message.", "bad")]))
    $ register_answer(scenario_result == "good")
    call screen card("Le petit montant sert surtout à récupérer\nles coordonnées bancaires.\n\nNe clique pas et ne réponds pas.")
    $ evidence_result = renpy.call_screen("question_card", "LA BONNE ACTION", "Que faire ensuite ?", shuffled([
        ("Supprimer le SMS et le signaler au 33700, sans ouvrir le lien.", "good"),
        ("Transférer le SMS à tous mes proches pour les prévenir.", "bad"),
        ("Appeler le numéro qui a envoyé le SMS.", "bad"),
        ("Ouvrir le lien uniquement en navigation privée.", "bad")]))
    $ register_answer(evidence_result == "good")
    call screen card("Le 33700 permet de signaler les SMS indésirables.\n\nÉvite de diffuser le lien frauduleux,\nmême pour prévenir.")
    jump s3

label s3:
    $ niveau = 3
    $ scenario_result = renpy.call_screen("question_card", "SITUATION 3 — Le professeur", "Un message reçu sur l'ENT, depuis le compte habituel\nde ta professeure, annonce un changement de salle.\nAucun lien, aucune pièce jointe et aucune donnée\npersonnelle ne sont demandés.", shuffled([
        ("Le message paraît légitime, tout en restant vérifiable.", "good"),
        ("C'est forcément un hameçonnage car le changement est inhabituel.", "bad"),
        ("Tout message numérique est suspect.", "bad"),
        ("Le compte connu prouve que toute vérification est inutile.", "bad")]))
    $ register_answer(scenario_result == "good")
    call screen card("Un message inhabituel n'est pas\nautomatiquement frauduleux.\n\nIci, le canal habituel et l'absence\nde demande sensible sont rassurants.")
    $ evidence_result = renpy.call_screen("question_card", "ÉVITER LE FAUX POSITIF", "Si tu veux confirmer, quelle action est proportionnée ?", shuffled([
        ("Consulter l'emploi du temps officiel\nou demander au professeur en classe.", "good"),
        ("Signaler immédiatement le compte de la professeure comme pirate.", "bad"),
        ("Ignorer le message sans aucune vérification.", "bad"),
        ("Demander le mot de passe du compte pour contrôler son identité.", "bad")]))
    $ register_answer(evidence_result == "good")
    call screen card("Vérifier ne signifie pas accuser.\n\nOn choisit un canal indépendant et proportionné.")
    jump s4

label s4:
    $ niveau = 4
    $ scenario_result = renpy.call_screen("question_card", "SITUATION 4 — La pièce jointe", "Objet : 'Facture en retard'\nPièce jointe : Facture_Septembre.pdf.exe\n\nLe message affirme qu'une pénalité\nsera appliquée aujourd'hui.", shuffled([
        ("C'est dangereux : la double extension\nmasque un programme exécutable.", "good"),
        ("Le mot PDF garantit qu'il s'agit d'un document.", "bad"),
        ("Je l'ouvre avec l'antivirus activé.", "bad"),
        ("Je l'ouvre sur mon téléphone plutôt que sur l'ordinateur.", "bad")]))
    $ register_answer(scenario_result == "good")
    call screen card("Une extension finale .exe désigne un programme.\n\nLe mot '.pdf' placé avant\npeut servir de déguisement.")
    $ evidence_result = renpy.call_screen("question_card", "LA BONNE ACTION", "Quelle conduite adopter ?", shuffled([
        ("Ne pas ouvrir et prévenir un adulte ou le référent.\nPuis supprimer ou mettre le fichier en quarantaine.", "good"),
        ("Renommer le fichier en .pdf puis l'ouvrir.", "bad"),
        ("L'envoyer à un camarade pour qu'il teste.", "bad"),
        ("Désactiver Internet avant de l'ouvrir.", "bad")]))
    $ register_answer(evidence_result == "good")
    call screen card("On ne teste jamais un fichier douteux\nsur l'appareil d'une autre personne.")
    jump s5

label s5:
    $ niveau = 5
    $ scenario_result = renpy.call_screen("question_card", "SITUATION 5 — Le QR code", "Une affiche près de l'arrêt de bus promet :\n'6 mois de transport gratuits — scannez vite'.\nUn autocollant QR semble avoir été ajouté\npar-dessus le code d'origine.", shuffled([
        ("C'est potentiellement du quishing : je ne scanne pas ce code.", "good"),
        ("Un QR code imprimé dans un lieu public est forcément fiable.", "bad"),
        ("Je scanne : le téléphone me protégera automatiquement.", "bad"),
        ("Je scanne seulement si l'affiche semble bien imprimée.", "bad")]))
    $ register_answer(scenario_result == "good")
    call screen card("Le quishing utilise un QR code\npour masquer une adresse frauduleuse.\n\nUn autocollant superposé est un indice important.")
    $ evidence_result = renpy.call_screen("question_card", "LA VÉRIFICATION", "Comment vérifier l'offre ?", shuffled([
        ("Aller sur le site ou l'application officielle\ndu réseau de transport.", "good"),
        ("Scanner le code puis fermer si la page paraît étrange.", "bad"),
        ("Photographier le code et le publier pour demander l'avis des autres.", "bad"),
        ("Recouvrir l'autocollant sans prévenir le réseau de transport.", "bad")]))
    $ register_answer(evidence_result == "good")
    call screen card("Comme pour un lien, utilise ton propre chemin\nvers le service officiel.")
    jump s6

label s6:
    $ niveau = 6
    $ scenario_result = renpy.call_screen("question_card", "SITUATION 6 — Le proche en difficulté", "Depuis le compte habituel d'un ami :\n'J'ai cassé mon téléphone. Peux-tu m'acheter\ndeux cartes cadeaux et m'envoyer les codes ?\nC'est urgent, n'appelle pas.'", shuffled([
        ("Le compte peut être piraté ou usurpé : je suspends toute action.", "good"),
        ("Le compte est connu, donc la demande est sûre.", "bad"),
        ("J'envoie une seule carte pour vérifier.", "bad"),
        ("Je demande uniquement le numéro de série des cartes.", "bad")]))
    $ register_answer(scenario_result == "good")
    call screen card("Un compte connu peut être compromis.\n\nLes cartes cadeaux sont recherchées,\ncar leurs codes sont rapidement utilisables.")
    $ evidence_result = renpy.call_screen("question_card", "LE SECOND CANAL", "Quelle vérification est la plus fiable ?", shuffled([
        ("Contacter l'ami par un autre moyen déjà connu, ou un proche commun.", "good"),
        ("Poser une question secrète dans la même messagerie.", "bad"),
        ("Demander une photo de la carte d'identité.", "bad"),
        ("Attendre qu'il insiste une seconde fois dans la même conversation.", "bad")]))
    $ register_answer(evidence_result == "good")
    call screen card("Un second canal indépendant\nréduit fortement le risque.\n\nN'exige jamais l'envoi d'un document d'identité.")
    jump s7

label s7:
    $ niveau = 7
    $ scenario_result = renpy.call_screen("question_card", "SITUATION 7 — Le cadenas", "Un site copiant parfaitement une plateforme connue\naffiche un cadenas. Son adresse est :\ncomptes-eleves-secure.net\nIl demande l'identifiant ENT.", shuffled([
        ("Le cadenas chiffre la connexion, mais ne prouve pas\nque le site est légitime.", "good"),
        ("Le cadenas garantit l'identité du propriétaire du site.", "bad"),
        ("La ressemblance visuelle suffit pour faire confiance.", "bad"),
        ("Un site en HTTPS ne peut pas voler de mot de passe.", "bad")]))
    $ register_answer(scenario_result == "good")
    call screen card("HTTPS protège le trajet des données.\n\nUn fraudeur peut lui aussi obtenir un certificat\net afficher un cadenas.")
    $ evidence_result = renpy.call_screen("question_card", "L'INDICE À LIRE", "Dans une adresse Web, que faut-il examiner en priorité ?", shuffled([
        ("Le nom de domaine réel, juste avant l'extension\n(.fr, .org, .com...).", "good"),
        ("La couleur et le design de la page.", "bad"),
        ("Le nombre de mots dans l'adresse.", "bad"),
        ("La présence du mot 'secure' dans l'adresse.", "bad")]))
    $ register_answer(evidence_result == "good")
    call screen card("Lis le domaine de droite à gauche\nautour de l'extension.\n\nMéfie-toi des noms ajoutant 'secure', 'connexion'\nou une marque imitée.")
    jump s8

label s8:
    $ niveau = 8
    $ scenario_result = renpy.call_screen("question_card", "SITUATION 8 — La réinitialisation attendue", "Tu viens de demander la réinitialisation de ton mot de passe\nsur le site officiel. Quelques secondes après, tu reçois\nun courriel depuis le domaine exact du service.\nLe lien expire dans 15 minutes\net aucune autre donnée n'est demandée.", shuffled([
        ("Le message est cohérent et probablement légitime,\nmais je contrôle encore l'adresse.", "good"),
        ("Toute notion d'urgence prouve un hameçonnage.", "bad"),
        ("Tout lien reçu par courriel est forcément dangereux.", "bad"),
        ("Le message est sûr uniquement parce qu'il est arrivé rapidement.", "bad")]))
    $ register_answer(scenario_result == "good")
    call screen card("Le contexte compte : tu as déclenché l'action,\nle message arrive aussitôt\net ne demande rien d'autre.\n\nUne durée limitée peut ici protéger le compte.")
    $ evidence_result = renpy.call_screen("question_card", "LA DÉCISION RAISONNÉE", "Quelle option reste la plus prudente ?", shuffled([
        ("Vérifier le domaine ou retourner sur le site officiel\npour recommencer la procédure.", "good"),
        ("Transférer le lien à un ami pour qu'il l'essaie.", "bad"),
        ("Répondre au courriel avec mon ancien mot de passe.", "bad"),
        ("Conserver le lien dans mes favoris avant de vérifier.", "bad")]))
    $ register_answer(evidence_result == "good")
    call screen card("Tu viens d'éviter un faux positif.\n\nLa vigilance consiste à vérifier le contexte\net les preuves, pas à refuser\nautomatiquement tout message.")
    jump bilan

label bilan:
    $ niveau = 8
    $ stop_music()
    if optional_audio_exists("audio/victory.ogg"):
        $ play_sfx("audio/victory.ogg")
    call screen final_screen
    return
